/* Geometry comes exclusively from the OMCSA annotation data; no inferred anatomical masks. */
(function () {
 'use strict';
 const labelKey = label => String(label?.en || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().replace(/\s+/g,' ').toLowerCase();
 const isInBounds = point => point && Number.isFinite(Number(point.percentWidth)) && Number.isFinite(Number(point.percentHeight)) && Number(point.percentWidth)>=0 && Number(point.percentWidth)<=1 && Number(point.percentHeight)>=0 && Number(point.percentHeight)<=1;
 function selectedStructureIds(project,key) {
  if(!key)return new Set();
  return new Set(Object.values(project.legends).filter(label=>labelKey(label)===key).map(label=>String(label.structure)));
 }
 function validRegion(points) {
  return Array.isArray(points)&&points.length>=3&&points.every(point=>Array.isArray(point)&&point.length>=2&&point.slice(0,2).every(value=>Number.isFinite(Number(value))&&Number(value)>=0&&Number(value)<=1));
 }
 function regionsForSelection(project,key,imageId) {
  const ids=selectedStructureIds(project,key);
  return Object.entries(project.structures||{}).filter(([id,structure])=>ids.has(id)&&validRegion(structure.draw?.[imageId])).map(([id,structure])=>({id,color:structure.color,points:structure.draw[imageId]}));
 }
 function selectionOnImage(project,key,image) {
  if(!key||!image)return false;
  return Object.entries(image.legends||{}).some(([id,point])=>isInBounds(point)&&labelKey(project.legends[id])===key)||regionsForSelection(project,key,image.id).length>0;
 }
 function wrap(text,width,fontSize,measure) {
  const lines=[];let line='';
  for(const word of String(text).split(/\s+/).filter(Boolean)) {
   const candidate=line?line+' '+word:word;
   if(line&&measure(candidate,fontSize)>width){lines.push(line);line=word;}else line=candidate;
   while(measure(line,fontSize)>width&&line.length>1){let cut=line.length-1;while(cut>1&&measure(line.slice(0,cut),fontSize)>width)cut--;lines.push(line.slice(0,cut));line=line.slice(cut);}
  }
  if(line)lines.push(line);return lines.length?lines:[''];
 }
 function layoutCallouts(labels,aspect,bilingual,masked,measure=(text,size)=>text.length*size*.55) {
  const imageWidth=1000,imageHeight=imageWidth*(Number.isFinite(aspect)&&aspect>0?aspect:1),gap=16,padding=32;
  const rows=labels.map(label=>{
   const hidden=masked(label),viLines=wrap(hidden?'Cấu trúc '+label.number:label.vi||label.en,460,27,measure);
   const enLines=bilingual&&!hidden?wrap(label.en,460,22,measure):[];
   return {...label,side:Number(label.position.percentWidth)<.5?'left':'right',viLines,enLines,blockHeight:viLines.length*32+(enLines.length?8+enLines.length*26:0)};
  });
  const sides=['left','right'].map(side=>rows.filter(row=>row.side===side).sort((a,b)=>Number(a.position.percentHeight)-Number(b.position.percentHeight)||a.id.localeCompare(b.id)));
  const imageX=sides[0].length?520:20,width=imageX+imageWidth+(sides[1].length?520:20);
  const total=side=>side.reduce((sum,row)=>sum+row.blockHeight+gap,0)- (side.length?gap:0);
  const height=Math.max(imageHeight,...sides.map(total))+padding*2;
  const image={x:imageX,y:(height-imageHeight)/2,width:imageWidth,height:imageHeight};
  for(const side of sides){
   let bottom=padding-gap;
   for(const row of side){row.targetX=image.x+Number(row.position.percentWidth)*imageWidth;row.targetY=image.y+Number(row.position.percentHeight)*imageHeight;row.center=Math.max(row.targetY,bottom+gap+row.blockHeight/2);bottom=row.center+row.blockHeight/2;}
   let top=height-padding+gap;
   for(const row of [...side].reverse()){row.center=Math.min(row.center,top-gap-row.blockHeight/2);top=row.center-row.blockHeight/2;}
  }
  return {width,height,image,rows:sides.flat()};
 }
 function regionPath(points,image) {
  if(!validRegion(points))return '';
  const scaled=points.map(([x,y])=>[image.x+Number(x)*image.width,image.y+Number(y)*image.height]);
  const pair=point=>point.join(' ');let path='M '+pair(scaled[0]);
  for(let i=1;i<scaled.length-1;i++)path+=' Q '+pair(scaled[i])+' '+pair([(scaled[i][0]+scaled[i+1][0])/2,(scaled[i][1]+scaled[i+1][1])/2]);
  return path+' Q '+pair(scaled[scaled.length-1])+' '+pair(scaled[0])+' Z';
 }
 const api={labelKey,isInBounds,selectedStructureIds,regionsForSelection,selectionOnImage,validRegion,layoutCallouts,regionPath};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;else window.AtlasDiagram=api;
})();
