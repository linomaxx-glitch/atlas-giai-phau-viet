'use strict';
const $ = id => document.getElementById(id);
const normalize = text => String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
const state = {catalog:[],project:null,images:[],index:0,selected:null,revealed:new Set(),route:0,layout:null};
const svgNS = 'http://www.w3.org/2000/svg';
const {labelKey,isInBounds,regionsForSelection,selectionOnImage,validRegion,layoutCallouts,regionPath}=AtlasDiagram;
function element(tag,text,className){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;}
async function getJSON(url){const result=await fetch(url);if(!result.ok)throw new Error(`Không tải được dữ liệu (HTTP ${result.status}).`);return result.json();}
function renderCatalog(){
 const query=normalize($('catalogSearch').value),group=$('region').value;
 const entries=state.catalog.filter(p=>(!group||p.groupVi===group)&&normalize(p.vi+' '+p.name).includes(query));
 $('catalog').replaceChildren();
 for(const project of entries){const link=element('a',undefined,'card');link.href='#atlas/'+project.id;
  const image=element('img');image.src=project.thumbnail;image.alt='Ảnh xem trước: '+project.vi;image.loading='lazy';image.width=100;image.height=100;
  image.addEventListener('error',()=>{image.hidden=true;},{once:true});
  const body=element('div');body.append(element('small',project.groupVi),element('h2',project.vi),element('small',project.name),element('p',project.imageCount+' ảnh • Mở atlas →'));link.append(image,body);$('catalog').append(link);
 }
 $('catalogStatus').textContent=entries.length?`${entries.length} / ${state.catalog.length} chuyên mục`:'Không tìm thấy chuyên mục. Thử từ khóa khác hoặc chọn tất cả vùng.';
}
async function route(){
 const token=++state.route;const match=location.hash.match(/^#atlas\/(\d+)$/);
 $('home').hidden=!!match;$('viewer').hidden=!match;
 if(!match){document.title='Giải phẫu cắt lớp • Atlas Việt';return;}
 state.project=null;$('viewerContent').hidden=true;$('projectStatus').className='';
 const entry=state.catalog.find(p=>p.id===match[1]);$('projectTitle').textContent=entry?.vi||'Chuyên mục giải phẫu';$('projectStatus').textContent='Đang tải dữ liệu chuyên mục…';
 try{const project=await getJSON('data/'+match[1]+'.json');if(token!==state.route)return;
  state.project=project;state.index=0;state.selected=null;state.revealed.clear();$('labelSearch').value='';$('series').replaceChildren();
  for(const series of project.series){const option=element('option',series.vi===series.en?series.en:series.vi+' · '+series.en);option.value=series.id;$('series').append(option);}
  if(!project.series.length){const option=element('option','Tất cả ảnh');option.value='';$('series').append(option);}
  document.title=project.title+' • Atlas Việt';$('projectTitle').textContent=project.title;
  $('projectStatus').textContent=`${project.images.length} ảnh${project.unavailableImages?.length?' có sẵn / '+project.sourceImageCount+' ảnh nguồn · '+project.unavailableImages.length+' ảnh không truy cập được trên nguồn':''} • Nguồn: OMCSA • Nhãn tiếng Việt cần thẩm định`;
  $('viewerContent').hidden=false;chooseSeries();window.scrollTo({top:0,behavior:'instant'});
 }catch(error){if(token!==state.route)return;$('projectStatus').className='error';$('projectStatus').textContent=error.message+' Hãy quay lại danh mục và thử lại.';}
}
function chooseSeries(){if(!state.project)return;state.images=state.project.images.filter(image=>!$('series').value||image.series===$('series').value);state.index=0;renderImage();}
function renderImage(){
 const image=state.images[state.index];state.revealed.clear();
 $('slice').max=Math.max(0,state.images.length-1);$('slice').value=state.index;$('slice').disabled=state.images.length<2;
 $('previous').disabled=state.index===0;$('next').disabled=state.index>=state.images.length-1;
 $('sliceCount').textContent=`${state.images.length?state.index+1:0} / ${state.images.length}`;
 if(!image){$('scan').removeAttribute('src');$('markers').replaceChildren();$('legends').replaceChildren();$('imageStatus').textContent='Chuỗi này không có ảnh.';return;}
 $('scan').alt=`${state.project.title}, lát cắt ${state.index+1} trong chuỗi đã chọn`;$('imageStatus').textContent='Đang tải ảnh…';
 $('scan').src=image.url;renderLegends();
}
function labelsOnImage(){const image=state.images[state.index];if(!image)return[];return Object.entries(image.legends||{}).map(([id,position])=>({id,position,...state.project.legends[id]})).filter(label=>(label.en||label.vi)&&isInBounds(label.position)).map((label,index)=>({...label,number:index+1}));}
const isSelected = label => !!state.selected&&labelKey(label)===state.selected;
const isMasked = label => $('quiz').checked&&!state.revealed.has(label.id);
function colorFor(structureId){
 const source=String(state.project.structures?.[structureId]?.color||'white');
 const colors={green:'#65d887',royalblue:'#91b8ff',gray:'#bcc7d0',darkorange:'#ffac42',blue:'#7aa8ff',red:'#ff7171'};
 return colors[source.toLowerCase()]||(CSS.supports('color',source)?source:'#e0e6ec');
}
function svg(tag,attributes={}){const node=document.createElementNS(svgNS,tag);for(const [name,value] of Object.entries(attributes))node.setAttribute(name,value);return node;}
function drawDiagram(labels){
 const scan=$('scan'),aspect=scan.naturalWidth?scan.naturalHeight/scan.naturalWidth:1;
 const measure=(text,size)=>{measure.context.font=size+'px Arial';return measure.context.measureText(text).width;};
 measure.context=document.createElement('canvas').getContext('2d');
 const layout=layoutCallouts(labels,aspect,$('bilingual').checked,isMasked,measure);state.layout=layout;
 const {image}=layout;const diagram=$('markers');diagram.replaceChildren();diagram.setAttribute('viewBox',`0 0 ${layout.width} ${layout.height}`);
 scan.style.left=image.x/layout.width*100+'%';scan.style.top=image.y/layout.height*100+'%';scan.style.width=image.width/layout.width*100+'%';scan.style.height=image.height/layout.height*100+'%';
 $('stage').style.aspectRatio=layout.width+' / '+layout.height;$('stage').dataset.selection=state.selected||'';
 const regions=svg('g',{'class':'region-layer'}),callouts=svg('g',{'class':'callout-layer'});diagram.append(regions,callouts);
 const imageId=state.images[state.index]?.id;
 const selectedRegions=new Set(regionsForSelection(state.project,state.selected,imageId).map(region=>region.id));
 for(const [sid,structure] of Object.entries(state.project.structures||{})){
  const points=structure.draw?.[imageId],selected=selectedRegions.has(sid);
  if(!validRegion(points)||(!selected&&!$('showRegions').checked))continue;
  const path=svg('path',{d:regionPath(points,image),fill:colorFor(sid),stroke:colorFor(sid),'class':'anatomical-region'+(selected?' selected':''),'data-structure-id':sid,'data-image-id':imageId});
  const label=Object.entries(state.project.legends).find(([,entry])=>String(entry.structure)===sid);
  if(label){path.setAttribute('role','button');path.setAttribute('tabindex','0');path.setAttribute('aria-label','Vùng '+(label[1].vi||label[1].en));path.addEventListener('click',()=>selectLabel(label[0],false));path.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectLabel(label[0],false);}});}
  regions.append(path);
 }
 callouts.hidden=!$('showMarkers').checked;
 // SVG does not consistently honor the HTML hidden property on <g>.
 callouts.setAttribute('display',$('showMarkers').checked?'inline':'none');
 for(const row of layout.rows){
  const selected=isSelected(row),masked=isMasked(row),left=row.side==='left';
  const edge=left?image.x:image.x+image.width;
  const color=selected?'#ffe079':colorFor(row.structure),anchorX=edge+(left?-20:20),elbowX=edge+(left?-8:8),textX=edge+(left?-40:40);
  const group=svg('g',{'class':'callout'+(selected?' selected':''),'role':'button','tabindex':'0','aria-pressed':String(selected),'aria-label':masked?'Cấu trúc '+row.number:row.vi+' · '+row.en,'data-legend-id':row.id});
  const leader=svg('polyline',{points:`${row.targetX},${row.targetY} ${elbowX},${row.center} ${anchorX},${row.center}`,stroke:color,'class':'leader'});
  const tick=svg('line',{x1:anchorX,x2:anchorX,y1:row.center-11,y2:row.center+11,stroke:color,'class':'leader'});
  const point=svg('circle',{cx:row.targetX,cy:row.targetY,r:selected?5:3,fill:color,'class':'anchor-point'});
  const hit=svg('rect',{x:left?16:anchorX,y:row.center-row.blockHeight/2-8,width:484,height:row.blockHeight+16,fill:'transparent','class':'callout-hit'});
  const text=svg('text',{x:textX,'text-anchor':left?'end':'start',fill:color,'class':'callout-name'});
  let baseline=row.center-row.blockHeight/2+25;
  for(const line of row.viLines){const span=svg('tspan',{x:textX,y:baseline});span.textContent=line;text.append(span);baseline+=32;}
  if(row.enLines.length){baseline+=2;for(const line of row.enLines){const span=svg('tspan',{x:textX,y:baseline,'class':'callout-english'});span.textContent=line;text.append(span);baseline+=26;}}
  const title=svg('title');title.textContent=masked?'Chọn để hiện đáp án':row.vi+' — '+row.en;
  group.append(title,leader,tick,point,hit,text);group.addEventListener('click',()=>selectLabel(row.id,false));group.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectLabel(row.id,false);}});callouts.append(group);
 }
 applyImageOptions();updateSelectionControls();
}
function updateSelectionControls(){
 const label=Object.values(state.project.legends).find(item=>isSelected(item));
 $('clearSelection').disabled=!label;
 if(!label){$('selectionStatus').textContent='Chọn tên cấu trúc bên cạnh ảnh để theo dõi qua các lát cắt.';$('previousMatch').disabled=true;$('nextMatch').disabled=true;return;}
 const indices=state.images.flatMap((image,index)=>selectionOnImage(state.project,state.selected,image)?[index]:[]);
 $('previousMatch').disabled=!indices.some(index=>index<state.index);$('nextMatch').disabled=!indices.some(index=>index>state.index);
 const current=state.images[state.index],regions=regionsForSelection(state.project,state.selected,current?.id);
 const present=selectionOnImage(state.project,state.selected,current);
 const detail=regions.length?'Đang tô vùng theo đường viền gốc.':present?'Lát này chưa có đường viền vùng; điểm và đường dẫn được làm sáng.':'Lát này chưa có điểm chú thích hoặc đường viền cho cấu trúc đã chọn.';
 $('selectionStatus').textContent=`Đang chọn: ${label.vi||label.en} · ${indices.length}/${state.images.length} lát có chú thích trong chuỗi. ${detail}`;
}
function renderLegends(){
 const labels=labelsOnImage(),query=normalize($('labelSearch').value);$('markers').replaceChildren();$('legends').replaceChildren();
 const filtered=labels.filter(label=>normalize(label.en+' '+label.vi).includes(query));
 $('legendCount').textContent=`${filtered.length} / ${labels.length} cấu trúc trên lát cắt này`;
 for(const label of filtered){
  const masked=isMasked(label);const card=element('div',undefined,'legend'+(isSelected(label)?' selected':''));card.id='legend-'+label.id;
  const button=element('button');button.type='button';button.setAttribute('aria-pressed',String(isSelected(label)));
  const content=element('span');content.append(element('span',masked?'Chọn để hiện đáp án':label.vi||'Chưa có bản dịch'),element('span',masked?'Cấu trúc số '+label.number:label.en,'en'));
  if(!masked){content.append(element('span',label.status==='approved'?'Bản dịch đã được người biên tập duyệt':label.status==='needs_review'?'GPT · Cần xác minh tên nguồn':'GPT · Chưa thẩm định chuyên môn','draft'));if(label.translationNote)content.append(element('span',label.translationNote,'translation-note'));}
  const swatch=element('span',undefined,'structure-swatch');swatch.style.background=colorFor(label.structure);swatch.setAttribute('aria-hidden','true');button.append(swatch,content);button.addEventListener('click',()=>selectLabel(label.id,false));card.append(button);
  if(!masked)for(const url of label.references||[]){try{const parsed=new URL(url);if(!['http:','https:'].includes(parsed.protocol))continue;const link=element('a','Tham khảo: '+parsed.hostname+' ↗','reference');link.href=parsed.href;link.target='_blank';link.rel='noopener noreferrer';card.append(link);}catch{}}
  $('legends').append(card);
 }
 if(!filtered.length)$('legends').append(element('p',query?'Không thấy cấu trúc trên lát cắt này. Nhấn Enter trong ô tìm kiếm để tìm lát cắt đầu tiên có cấu trúc phù hợp.':'Lát cắt này không có chú thích.'));
 drawDiagram(filtered);
}
function selectLabel(id){const label=state.project.legends[id];if(!label)return;state.selected=labelKey(label);state.revealed.add(id);renderLegends();}
function move(delta){if(!state.project)return;state.index=Math.max(0,Math.min(state.images.length-1,state.index+delta));renderImage();}
function moveToMatch(direction){if(!state.selected)return;for(let index=state.index+direction;index>=0&&index<state.images.length;index+=direction){if(selectionOnImage(state.project,state.selected,state.images[index])){state.index=index;renderImage();return;}}}
function applyImageOptions(){const image=$('scan'),container=$('stage').parentElement;const width=Math.max(container.clientWidth,1060);$('stage').style.width=width*Number($('zoom').value)/100+'px';$('stage').style.margin='0 auto';image.style.filter=`contrast(${$('contrast').value}%)`;}
$('scan').addEventListener('load',()=>{$('imageStatus').textContent='';applyImageOptions();if(state.project)renderLegends();});
$('scan').addEventListener('error',()=>{$('imageStatus').textContent='Không tải được ảnh này. Kiểm tra tệp ảnh trong gói triển khai hoặc thử lát cắt khác.';});
$('catalogSearch').addEventListener('input',renderCatalog);$('region').addEventListener('change',renderCatalog);
$('series').addEventListener('change',chooseSeries);$('previous').addEventListener('click',()=>move(-1));$('next').addEventListener('click',()=>move(1));
$('slice').addEventListener('input',()=>{state.index=Number($('slice').value);renderImage();});
$('showMarkers').addEventListener('change',renderLegends);$('quiz').addEventListener('change',()=>{state.revealed.clear();renderLegends();});
$('bilingual').addEventListener('change',renderLegends);$('showRegions').addEventListener('change',renderLegends);
$('clearSelection').addEventListener('click',()=>{state.selected=null;renderLegends();});
$('previousMatch').addEventListener('click',()=>moveToMatch(-1));$('nextMatch').addEventListener('click',()=>moveToMatch(1));
$('zoom').addEventListener('input',applyImageOptions);$('contrast').addEventListener('input',applyImageOptions);
$('labelSearch').addEventListener('input',()=>{if(state.project)renderLegends();});
$('labelSearch').addEventListener('keydown',event=>{if(event.key!=='Enter'||!state.project)return;const query=normalize(event.target.value);if(!query)return;
 const match=state.project.images.find(image=>Object.keys(image.legends||{}).some(id=>{const label=state.project.legends[id];return label&&normalize(label.en+' '+label.vi).includes(query);}));
 if(!match){$('legendCount').textContent='Không tìm thấy cấu trúc trong chuyên mục này.';return;}
 if($('series').value!==match.series){$('series').value=match.series;chooseSeries();}state.index=state.images.findIndex(image=>image.id===match.id);if(state.index>=0)renderImage();
});
document.addEventListener('keydown',event=>{if($('viewer').hidden||event.target.closest('input,select,textarea,button,a,[role=button]'))return;if(event.key==='ArrowLeft'){event.preventDefault();move(-1);}if(event.key==='ArrowRight'){event.preventDefault();move(1);}});
window.addEventListener('hashchange',route);
window.addEventListener('resize',applyImageOptions);
(async()=>{try{state.catalog=await getJSON('data/catalog.json');for(const group of new Set(state.catalog.map(p=>p.groupVi))){const option=element('option',group);option.value=group;$('region').append(option);}renderCatalog();await route();}catch(error){$('catalogStatus').className='error';$('catalogStatus').textContent=error.message+' Hãy mở website qua máy chủ HTTP, không mở trực tiếp tệp HTML.';}})();
